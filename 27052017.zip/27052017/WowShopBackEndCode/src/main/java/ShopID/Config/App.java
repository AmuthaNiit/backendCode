package ShopID.Config;

import ShopID.productModel.Model;
import ShopID.productModel.categoryModel;
//import ShopID.productService.productservice;
import ShopID.productService.productservice;

public class App {

	public static void main(String[] arg){
	
		/* productservice ps= new productservice();
		
    Model p1=new Model("101","Bandhini","BlackGray","sarees",2750,1,"Women Wear","Supplier");
    Model p2= new Model("111", "branded", "Karishma", "Fancy type", 1000,12,"Saree",
			"KMp Co.");
    Model p3 = new Model("113", "Handlom11", "Kalasetra11", "Cottorn type11", 1500,12,"Saree","KMp Co."); 
	System.out.println("*** Persist - start ***");
   	ps.persist(p1);
   	ps.persist(p2);
   	ps.persist(p3); */
		
		System.out.println("Working");
   	
   	
   	
}
}